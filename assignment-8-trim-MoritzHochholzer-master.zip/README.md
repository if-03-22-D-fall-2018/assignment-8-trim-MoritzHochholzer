### if.03.22 Procedural Programming
# Assignment – Strings
## trim
With this assignment you are to experiments with strings in C. Clone this assignment, open the index.html read the assignment and try to make all unit tests green.
